/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F47Q10
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB 	          :  MPLAB X 5.45	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set CLK aliases
#define CLK_TRIS                 TRISAbits.TRISA0
#define CLK_LAT                  LATAbits.LATA0
#define CLK_PORT                 PORTAbits.RA0
#define CLK_WPU                  WPUAbits.WPUA0
#define CLK_OD                   ODCONAbits.ODCA0
#define CLK_ANS                  ANSELAbits.ANSELA0
#define CLK_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define CLK_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define CLK_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define CLK_GetValue()           PORTAbits.RA0
#define CLK_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define CLK_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define CLK_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define CLK_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define CLK_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define CLK_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define CLK_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define CLK_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set DAT aliases
#define DAT_TRIS                 TRISAbits.TRISA1
#define DAT_LAT                  LATAbits.LATA1
#define DAT_PORT                 PORTAbits.RA1
#define DAT_WPU                  WPUAbits.WPUA1
#define DAT_OD                   ODCONAbits.ODCA1
#define DAT_ANS                  ANSELAbits.ANSELA1
#define DAT_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define DAT_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define DAT_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define DAT_GetValue()           PORTAbits.RA1
#define DAT_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define DAT_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define DAT_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define DAT_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define DAT_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define DAT_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define DAT_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define DAT_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set SW1 aliases
#define SW1_TRIS                 TRISAbits.TRISA2
#define SW1_LAT                  LATAbits.LATA2
#define SW1_PORT                 PORTAbits.RA2
#define SW1_WPU                  WPUAbits.WPUA2
#define SW1_OD                   ODCONAbits.ODCA2
#define SW1_ANS                  ANSELAbits.ANSELA2
#define SW1_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SW1_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SW1_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SW1_GetValue()           PORTAbits.RA2
#define SW1_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SW1_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define SW1_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define SW1_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define SW1_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define SW1_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define SW1_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set SW2 aliases
#define SW2_TRIS                 TRISAbits.TRISA3
#define SW2_LAT                  LATAbits.LATA3
#define SW2_PORT                 PORTAbits.RA3
#define SW2_WPU                  WPUAbits.WPUA3
#define SW2_OD                   ODCONAbits.ODCA3
#define SW2_ANS                  ANSELAbits.ANSELA3
#define SW2_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define SW2_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define SW2_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define SW2_GetValue()           PORTAbits.RA3
#define SW2_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define SW2_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define SW2_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define SW2_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define SW2_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define SW2_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define SW2_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define SW2_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set SW3 aliases
#define SW3_TRIS                 TRISBbits.TRISB0
#define SW3_LAT                  LATBbits.LATB0
#define SW3_PORT                 PORTBbits.RB0
#define SW3_WPU                  WPUBbits.WPUB0
#define SW3_OD                   ODCONBbits.ODCB0
#define SW3_ANS                  ANSELBbits.ANSELB0
#define SW3_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define SW3_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define SW3_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define SW3_GetValue()           PORTBbits.RB0
#define SW3_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define SW3_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define SW3_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define SW3_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define SW3_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define SW3_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define SW3_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define SW3_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set LED aliases
#define LED_TRIS                 TRISCbits.TRISC5
#define LED_LAT                  LATCbits.LATC5
#define LED_PORT                 PORTCbits.RC5
#define LED_WPU                  WPUCbits.WPUC5
#define LED_OD                   ODCONCbits.ODCC5
#define LED_ANS                  ANSELCbits.ANSELC5
#define LED_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define LED_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define LED_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define LED_GetValue()           PORTCbits.RC5
#define LED_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define LED_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define LED_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set HF1 aliases
#define HF1_TRIS                 TRISDbits.TRISD0
#define HF1_LAT                  LATDbits.LATD0
#define HF1_PORT                 PORTDbits.RD0
#define HF1_WPU                  WPUDbits.WPUD0
#define HF1_OD                   ODCONDbits.ODCD0
#define HF1_ANS                  ANSELDbits.ANSELD0
#define HF1_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define HF1_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define HF1_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define HF1_GetValue()           PORTDbits.RD0
#define HF1_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define HF1_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define HF1_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define HF1_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define HF1_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define HF1_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define HF1_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define HF1_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set HF2 aliases
#define HF2_TRIS                 TRISDbits.TRISD1
#define HF2_LAT                  LATDbits.LATD1
#define HF2_PORT                 PORTDbits.RD1
#define HF2_WPU                  WPUDbits.WPUD1
#define HF2_OD                   ODCONDbits.ODCD1
#define HF2_ANS                  ANSELDbits.ANSELD1
#define HF2_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define HF2_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define HF2_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define HF2_GetValue()           PORTDbits.RD1
#define HF2_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define HF2_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define HF2_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define HF2_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define HF2_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define HF2_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define HF2_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define HF2_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/