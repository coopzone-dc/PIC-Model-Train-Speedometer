
#include "mcc_generated_files/mcc.h"
#include "tm1651.h"
#include "stdint.h"

void tm_start(void)
{
     CLK_LAT = HIGH;
     DAT_LAT = HIGH;
     __delay_us(CLKSPEED/2);
     DAT_LAT = LOW;
     __delay_us(CLKSPEED/2);
     CLK_LAT = LOW;
     __delay_us(CLKSPEED/2);
}

void tm_stop(void)
{
     CLK_LAT = LOW;
     DAT_LAT = LOW;
     __delay_us(CLKSPEED);
     CLK_LAT = HIGH;
     __delay_us(CLKSPEED/2);
     DAT_LAT = HIGH;
     __delay_us(CLKSPEED/2); //may need no /2
}

uint8_t tm_writeByte(uint8_t wr_data)
{
    uint8_t i,count1;
    for(i=0;i<8;i++)
    {
        CLK_LAT = LOW;
        if(wr_data & 0x01) DAT_LAT =HIGH;
        else DAT_LAT = LOW;
        wr_data >>= 1;
        __delay_us(CLKSPEED);
        CLK_LAT = HIGH;
        __delay_us(CLKSPEED);
    }
    CLK_LAT = LOW;
    //DAT_LAT = HIGH; 
    //CLK_LAT = HIGH;
    DAT_TRIS = HIGH; //set as input
    __delay_us(CLKSPEED/2);
    uint8_t ack = DAT_GetValue();
    if (ack == 0)
    {
        DAT_TRIS = LOW;
        DAT_LAT = LOW;
    }
    __delay_us(CLKSPEED/2);
    CLK_LAT=HIGH;
    DAT_TRIS = LOW;
    DAT_LAT = LOW; 
    __delay_us(CLKSPEED);
    return ack;
}

void tm_display(int8_t BitAddr, int8_t DispData)
{
    tm_start();
    tm_writeByte(ADDR_FIXED);
    tm_stop();
    tm_start();
    tm_writeByte(BitAddr|STARTADDR);
    tm_writeByte(DispData);
    tm_stop();
}

void tm_display4(int8_t segdata[])
{
    int8_t i;
    
    tm_start();
    tm_writeByte(ADDR_AUTO);
    tm_stop();
    tm_start();
    tm_writeByte((uint8_t) 0xc0);  //start address first digit.
    for(i=0;i<4;i++)
    {
        tm_writeByte(chr[segdata[i]]);
    }
    tm_stop();
}

void displayClear(void)
{
  for(int8_t loopx=0;loopx<4;loopx++)  //clears both 4 and 3 digit displays
      tm_display(loopx,0x0);
}

void displayNumber(uint16_t num)
{   //display integer number
    uint8_t pos=0;
    for(int8_t loopx=1;loopx<4;loopx++) // starts at pos, with hundreds then 10's then 1's
    {
     tm_display(pos, chr[(num / divisor[loopx]) % 10]); 
     pos++;
    }
}

void displayBrightness(int8_t b)
{
    tm_start();
    tm_writeByte(0x88 + b);
    tm_stop();
}

