/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F47Q10
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "tm1651.h"
#include <stdint.h>

static uint32_t mills=0,timeout,ledflash=0;
static uint32_t SW1,SW2,SW3;
static uint8_t stage,mainmenu=0,ledstatus=0,ledmax=DisplayOn1,ledmin=DisplayOn1;

static uint8_t scale[] = {76,48,87,148,220};//OO,O,N,z
static uint8_t sgap[] = {100,75,50,30}; //distance between sensors in CM
static uint8_t cscale=0;
static uint8_t sdist=0; //default sgap lookup for distance between sensors

//temp
//static uint16_t sdist;

   
void TMR2_int(void){
    // clear the TMR2 interrupt flag
    PIR4bits.TMR2IF = 0;
    mills++;
    if (!SW1_PORT) {SW1++;} else SW1=0;
    if (!SW2_PORT) {SW2++;} else SW2=0;
    if (!SW3_PORT) {SW3++;} else SW3=0;
    if (ledflash++ > LEDTIMER){
        ledflash=0;
        ledstatus = ~ledstatus;
       // LED_LAT = ledstatus;
        if (ledstatus && ledmin != ledmax) 
            displayBrightness(ledmin);
        else
            displayBrightness(ledmax);

    }
}

void flash(uint8_t flashbright, uint8_t flashdim) {
    ledmax=flashbright;
    ledmin=flashdim;
}

void loopReset(void) {
    int8_t i;
    flash(DisplayOn1,DisplayOn1);
    displayClear();
    for(i=0;i<3;i++)
    {
      tm_display(i,64); //turn on single row of "-"
    }
    mills=0;
    HF1_LAT=1; HF2_LAT=1; //power on both hall effect sensors
    timeout=MCOUNT;
    stage=0; mainmenu=0;
}

void calcmph(uint32_t finishmillis)
{
 float elapsed, miles, hours, mph;
 uint16_t scaleMPH;
 
  elapsed = (float)finishmillis / 1000;    //seconds
  miles = (float)sgap[sdist] / 160934;//miles there are 160934 cm in 1 mile
  hours = elapsed / 3600;   //hours
  mph = miles / hours;
  scaleMPH = (uint16_t) (mph * (float)scale[cscale] + 0.5);//rounding
   //use normal brightnessif between 50 and 69 scale MPH
   //if over 70mph use bright
  flash(DisplayOn1,DisplayOn1); //default to lowest brightness
  if ((scaleMPH >= 50) && (scaleMPH < 70)) {
        flash(DisplayOn14,DisplayOn14);
    } else if (scaleMPH >= 70) {
        flash(DisplayOn14,DisplayOn0);
  }
   displayNumber((uint16_t)scaleMPH);    
   
}

void displayMenu(uint8_t item)
{
    displayClear();
    tm_display(1, chr[item]);   
    tm_display(0,64+1+8); //make first display show "-"
    tm_display(2,0); // blank last display
}
/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    TMR2_SetInterruptHandler(TMR2_int);
    TMR2_Start();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    cscale = DATAEE_ReadByte(ESCALE);
    if (cscale > MAXCSCALE) //check for out of bounds value
        {
            DATAEE_WriteByte(ESCALE, 0);
            cscale =0;
        }
      sdist = DATAEE_ReadByte(ESDIST);
    if (sdist > 2) //check for out of bounds value
        {
            DATAEE_WriteByte(ESDIST, 0);
            sdist =0;
        }
 //after loopreset display the current setting of scale for around mph about 10sec
 loopReset();   
 timeout=2500;
 displayNumber((uint16_t)scale[cscale]);
 __delay_ms(1250);
 displayNumber((uint16_t)sgap[sdist]);

    while (1)
    {
        // Add your application code
        //LED_LAT = 1;
        
        if (mills > timeout) loopReset();  //back to standby display
        if (SW3 > DEBOUNCE ) 
        {
          stage=4;
          mills=0; timeout=MCOUNT_INMENU;
          //mainmenu=0;
          //while (SW3 !=0 ) {}; //wait for switch release
          //__delay_ms(20);
        }
        switch(stage) //normal display stages + menu 4->
        {
            case 0:
                    if(SW1 > DEBOUNCE) {
                        displayNumber(1);
                        mills=0; stage=1;
                    } 
                    if(SW2 > DEBOUNCE) {
                        displayNumber(2);
                        mills=0; stage=2;
                    }
                    break;
            case 1:
                    HF1_LAT=0; //turn off HF sensor once triggered
                    if(SW2 > DEBOUNCE) {
                        stage=3;
                    }
                    break;
            case 2:
                    HF2_LAT=0; //turn off HF sensor once triggered
                    if(SW1 > DEBOUNCE) {
                        stage=3;
                    }
                    break;
            case 3:
                    calcmph(mills);
                    HF2_LAT=0; HF1_LAT=0; //turn off witch ever sensor was left on
                    while( (SW1 !=0) || (SW2 !=0) ) {} //wait for sensors to clear
                    mills=0; stage=0; timeout=MCOUNT_MPH;
                    while(mills < timeout){}; //wait for timeout stops re-trigering
                    break;
            case 4:
                    while(mills < timeout) // main menu items
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while (SW3 !=0) {} //wait for the switch to be released
                            mainmenu++;
                            if (mainmenu > MAXMENU) mainmenu=0;
                            mills=0;
                            displayMenu(mainmenu);
                        }
                    }
                    mills=0;
                    switch(mainmenu)
                    {
                        case 0:
                                stage=0; //menu 0 exits back without change
                                break;
                        case 1:
                                stage=5; //menu 1 is the guage menu
                                break;
                    
                        case 2:
                                stage=7; //set sensor distance
                                break;
                    }
                    break;
            case 5:
                    displayNumber((uint16_t)scale[cscale]);
                    while(mills < timeout)
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while ( SW3 !=0 ){}; //wait for release
                            cscale++;
                            if (cscale > MAXCSCALE) cscale=0;
                            mills=0; 
                            displayNumber((uint16_t)scale[cscale]);
                        }
                    }
                    mills=0;stage=6;
                    break;
            
            case 6:
                   displayNumber((uint16_t)scale[cscale]);
                   flash(DisplayOn14,DisplayOn0);
                   DATAEE_WriteByte(ESCALE, cscale);
                   mills=0; timeout=MCOUNT_INMENU;
                   stage=0;
                   break;
            case 7:
                    displayNumber((uint16_t)sgap[sdist]);
                    while(mills < timeout)
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while ( SW3 !=0 ){}; //wait for release
                            sdist++;
                            if (sdist > MAXSDIST) sdist=0;
                            mills=0; 
                            displayNumber((uint16_t)sgap[sdist]);
                        }
                    }
                    mills=0;stage=8;
                    break;
            case 8:
                   displayNumber((uint16_t)sgap[sdist]);
                   flash(DisplayOn14,DisplayOn0);
                   DATAEE_WriteByte(ESDIST, sdist);
                   mills=0; timeout=MCOUNT_INMENU;
                   stage=0;
                   break;
     
        }
        
    }
}
/**
 End of File
*/